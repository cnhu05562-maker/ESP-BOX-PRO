package com.example.espboxdemo;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Switch;
import android.widget.CompoundButton;
import android.view.Gravity;
import android.graphics.Typeface;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(24, 36, 24, 24);
        page.setBackgroundColor(Color.rgb(16,16,20));

        TextView title = new TextView(this);
        title.setText("ESP BOX PRO");
        title.setTextColor(Color.RED);
        title.setTextSize(26);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        page.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("DEMO MODE • MỤC TIÊU GIẢ LẬP");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 8, 0, 20);
        page.addView(subtitle);

        Switch toggle = new Switch(this);
        toggle.setText("Bật ESP Box demo");
        toggle.setTextColor(Color.WHITE);
        toggle.setChecked(true);
        page.addView(toggle);

        DemoView demo = new DemoView(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        lp.topMargin = 20;
        page.addView(demo, lp);
        toggle.setOnCheckedChangeListener((CompoundButton button, boolean checked) -> {
            demo.setVisibleDemo(checked);
        });

        TextView note = new TextView(this);
        note.setText("Chỉ hiển thị khung nhân vật mẫu trong ứng dụng riêng. Không đọc dữ liệu hoặc can thiệp Free Fire.");
        note.setTextColor(Color.GRAY);
        note.setTextSize(12);
        note.setPadding(0, 16, 0, 0);
        page.addView(note);
        setContentView(page);
    }

    static class DemoView extends View {
        Paint p = new Paint(3);
        boolean visible = true;
        DemoView(Activity a) { super(a); setBackgroundColor(Color.rgb(28,28,34)); }
        void setVisibleDemo(boolean v) { visible = v; invalidate(); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            if (!visible) return;
            float x = getWidth() * 0.35f, y = getHeight() * 0.20f;
            float w = getWidth() * 0.30f, h = getHeight() * 0.48f;
            p.setColor(Color.RED); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5);
            c.drawRect(x, y, x+w, y+h, p);
            p.setStyle(Paint.Style.FILL); p.setTextSize(34); p.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawText("PLAYER 01", x-5, y-18, p);
            p.setColor(Color.GREEN); p.setStrokeWidth(10);
            c.drawLine(x, y+h+20, x+w, y+h+20, p);
            p.setColor(Color.WHITE); p.setTextSize(26); p.setTypeface(Typeface.DEFAULT);
            c.drawText("Khoảng cách: 25 m", x-20, y+h+65, p);
        }
    }
}
